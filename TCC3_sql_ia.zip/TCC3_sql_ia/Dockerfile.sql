# Dockerfile para o serviço SQL (7_sql_service.py)
FROM python:3.11-slim

# Define o diretório de trabalho dentro do container
WORKDIR /app

# Copia o arquivo de requisitos e instala as dependências
COPY requirements.sql.txt .
RUN pip install --no-cache-dir -r requirements.sql.txt

# Copia o código da aplicação e o banco de dados
COPY TCC2/7_sql_service.py .
COPY TCC2/abep_dados.db .

# Expõe a porta que o Flask está rodando (5001)
EXPOSE 5001

# Comando para rodar a aplicação
CMD ["python", "7_sql_service.py"]
