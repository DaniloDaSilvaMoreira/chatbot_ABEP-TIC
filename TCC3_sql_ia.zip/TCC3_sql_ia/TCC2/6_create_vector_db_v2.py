import json
import os
import re
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_ollama.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.docstore.document import Document

# Nome do arquivo JSON gerado pelo Bloco 3 (web_scraper.py)
JSON_FILE = 'documentos_coletados.json'
# Nome da pasta onde o índice FAISS será salvo
FAISS_INDEX_DIR = "faiss_index_abep_tic"

def load_documents_from_json(file_path):
    """Carrega os documentos do arquivo JSON e aplica a limpeza de texto."""
    if not os.path.exists(file_path):
        print(f"❌ Erro: Arquivo de documentos não encontrado em '{file_path}'.")
        print("Certifique-se de ter executado o script 'web_scraper.py' (Bloco 3) primeiro.")
        return None
        
    print(f"--- Carregando documentos de '{file_path}' ---")
    with open(file_path, 'r', encoding='utf-8') as f:
        documentos_coletados = json.load(f)
        
    print("\nAplicando limpeza adicional de texto (removendo espaços e quebras de linha excessivas)...")
    
    # --- MELHORIA 2: Limpeza adicional do texto antes de criar os Documentos LangChain ---
    for doc in documentos_coletados:
        # Remove quebras de linha múltiplas, deixando no máximo duas
        doc['content'] = re.sub(r'\n\s*\n', '\n\n', doc['content'])
        # Remove espaços múltiplos, deixando apenas um
        doc['content'] = re.sub(r'\s\s+', ' ', doc['content'])
        
    print(f"✅ {len(documentos_coletados)} documentos carregados e limpos com sucesso.")

    # 1. Preparar os documentos no formato que a LangChain espera
    documentos_langchain = [
        Document(page_content=doc['content'], metadata={'source': doc['source']}) 
        for doc in documentos_coletados
    ]
    
    return documentos_langchain

def create_and_save_vector_db():
    """Cria o banco de dados vetorial FAISS e o salva localmente."""
    
    documentos_langchain = load_documents_from_json(JSON_FILE)
    if not documentos_langchain:
        return

    # 2. Dividir os documentos em pedaços (chunks)
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=400,
        chunk_overlap=100,
        length_function=len
    )
    docs_split = text_splitter.split_documents(documentos_langchain)

    print(f"Estratégia de chunking refinada. O número de documentos foi de {len(documentos_langchain)} para {len(docs_split)} chunks.")

    # 3. Inicializar o modelo de embeddings
    print("\n--- Inicializando modelo de embeddings e criando o índice ---")
    try:
        embedding_model = OllamaEmbeddings(model="nomic-embed-text", base_url="http://localhost:11434")
    except Exception as e:
        print(f"❌ Erro ao inicializar o modelo de embeddings: {e}")
        print("Verifique se a biblioteca 'sentence-transformers' está instalada corretamente.")
        return

    # 4. Criar o novo banco de dados vetorial com os chunks refinados
    print("Recriando o banco de dados vetorial (FAISS)... Isso pode demorar um pouco.")
    vector_store = FAISS.from_documents(docs_split, embedding_model)
    print("Banco de dados vetorial criado com sucesso!")

    # 5. Salvar o novo índice localmente
    vector_store.save_local(FAISS_INDEX_DIR)
    print(f"✅ Novo índice salvo localmente na pasta '{FAISS_INDEX_DIR}'.")

if __name__ == "__main__":
    create_and_save_vector_db()
    print("\n" + "="*60)
    print("      PROCESSO DE CRIAÇÃO DO FAISS CONCLUÍDO")
    print("="*60)
