import requests
from bs4 import BeautifulSoup
import time

# Lista de URLs alvo, exatamente como você pediu.
URLS_FOCO = [
    'https://abep-tic.org.br/',
    'https://abep-tic.org.br/quem-somos-2/',
    'https://abep-tic.org.br/indice-abep-2020/',
    'https://abep-tic.org.br/indice-abep-2021/',
    'https://abep-tic.org.br/indice-abep-2022/',
    'https://abep-tic.org.br/indice-abep-2023/',
    'https://abep-tic.org.br/indice-abep-2024/',
    'https://abep-tic.org.br/indice-abep-2025/'
]

def extrair_texto_focado(url, headers):
    """Extrai o texto limpo de uma única URL."""
    try:
        response = requests.get(url, headers=headers, timeout=15)
        # Lança um erro para códigos de status HTTP ruins (4xx ou 5xx)
        response.raise_for_status()
        
        # Garante que o conteúdo seja decodificado corretamente, se possível
        response.encoding = response.apparent_encoding
        
        soup = BeautifulSoup(response.content, 'html.parser')

        # Limpa elementos irrelevantes
        for element in soup(['script', 'style', 'nav', 'footer', 'header', 'form']):
            element.decompose()

        text = soup.get_text(separator=' ', strip=True)
        return text
    except requests.RequestException as e:
        print(f"Erro ao acessar {url}: {e}")
        return None

def coletar_dados_focados(lista_urls):
    """Coleta o texto de uma lista pré-definida de URLs."""
    # User-Agent para simular um navegador e evitar bloqueios
    headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36' }
    documentos = []

    print("--- Iniciando coleta FOCADA de dados ---")

    for url in lista_urls:
        print(f"Coletando de: {url}...")
        texto_pagina = extrair_texto_focado(url, headers)
        if texto_pagina:
            documentos.append({'source': url, 'content': texto_pagina})
        time.sleep(0.1) # Pausa para não sobrecarregar o servidor

    return documentos

# Executa a coleta focada
documentos_coletados = coletar_dados_focados(URLS_FOCO)

print(f"\n✅ Coleta FOCADA finalizada! {len(documentos_coletados)} páginas foram processadas com sucesso.")
if documentos_coletados:
    print("\n--- Exemplo de conteúdo coletado (página inicial) ---")
    # Imprime os primeiros 500 caracteres do conteúdo da primeira página
    print(documentos_coletados[0]['content'][:500] + "...")

# O resultado final (documentos_coletados) pode ser usado em blocos de código subsequentes
# Para fins de demonstração, vamos salvar o resultado em um arquivo JSON
import json
with open('documentos_coletados.json', 'w', encoding='utf-8') as f:
    json.dump(documentos_coletados, f, ensure_ascii=False, indent=4)
    
print("\n✅ Dados salvos em 'documentos_coletados.json'")