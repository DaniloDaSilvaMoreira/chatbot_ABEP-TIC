# Projeto Agente ABEP-TIC (TCC)

Este projeto implementa um agente de IA com arquitetura de microsserviços para analisar e responder perguntas sobre o índice ABEP-TIC.

## Como Executar (Localmente com VS Code)

### Pré-requisitos

1.  **Python:** Garanta que você tenha o Python 3.10 ou superior instalado.
2.  **Ollama:** Você precisa ter o Ollama instalado e rodando na sua máquina.
    * Faça o download em [ollama.com](https://ollama.com/).
    * Após instalar, rode o seguinte comando no seu terminal para baixar o modelo de IA:
        ```bash
        ollama pull phi4-mini
        ```

### Passo 1: Configurar o Ambiente

1.  Crie um ambiente virtual (recomendado):
    ```bash
    python -m venv venv
    source venv/bin/activate  # No Windows: .\venv\Scripts\activate
    ```
2.  Instale todas as dependências:
    ```bash
    pip install -r requirements.txt
    ```

### Passo 2: Preparar os Dados (Rodar apenas UMA VEZ)

Execute o script de preparação para fazer o scraping dos sites, criar o banco de dados SQL e o índice vetorial FAISS.

```bash
python 1_preparar_ambiente.py