import subprocess
import sys

def install_packages():
    """Instala pacotes listados em requirements.txt usando pip."""
    print("Iniciando a instalação dos pacotes...")
    try:
        # Usa o pip associado ao ambiente Python atual
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "1_requirements.txt"])
        print("✅ Pacotes instalados com sucesso!")
    except subprocess.CalledProcessError as e:
        print(f"❌ Erro durante a instalação dos pacotes: {e}")
        sys.exit(1)

def verify_installation():
    """Verifica se os principais pacotes foram instalados."""
    print("\nVerificando a instalação...")
    
    # Lista de pacotes a serem verificados (removido "faiss-cpu")
    packages_to_check = [
        "bs4", "sentence_transformers", "faiss", 
        "ollama", "langchain_core", "langchain", 
        "langchain_community", "langchain_ollama",
        "streamlit", "flask", "pandas", "requests", 
        "matplotlib", "PIL", "bcrypt"
        # "faiss-cpu" foi removido daqui
    ]
    
    all_ok = True
    for package_name in packages_to_check:
        try:
            # Para PIL (Pillow), o módulo de importação é 'PIL'
            if package_name == "PIL":
                __import__("PIL")
            else:
                __import__(package_name)
            print(f"  - {package_name}: OK")
        except ImportError:
            print(f"  - {package_name}: FALHOU (Não encontrado)")
            all_ok = False
            
    if all_ok:
        print("✅ Verificação de instalação concluída com sucesso!")
    else:
        print("❌ A verificação encontrou pacotes faltando. Por favor, verifique o log de instalação.")


if __name__ == "__main__":
    install_packages()
    verify_installation()
