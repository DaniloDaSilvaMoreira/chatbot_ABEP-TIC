import subprocess
import sys
import os
import time

def check_ollama_status():
    """Verifica se o servidor Ollama está rodando."""
    print("--- Verificando o status do servidor Ollama ---")
    try:
        # Tenta executar um comando simples do Ollama para verificar se o servidor está acessível
        # O comando 'ollama list' é seguro e rápido
        # Adicionando encoding='utf-8' para evitar UnicodeDecodeError no Windows
        result = subprocess.run(
            ['ollama', 'list'], 
            capture_output=True, 
            text=True, 
            check=True, 
            timeout=10,
            encoding='utf-8', # Adicionado para corrigir o UnicodeDecodeError
            errors='ignore' # Adicionado para ignorar caracteres inválidos, se houver
        )
        print("✅ Servidor Ollama está rodando e acessível.")
        return True
    except FileNotFoundError:
        print("❌ Comando 'ollama' não encontrado. Certifique-se de que o Ollama está instalado e no PATH.")
        print("   Consulte o arquivo README_OLLAMA.md para instruções de instalação.")
        return False
    except subprocess.CalledProcessError:
        print("❌ O comando 'ollama list' falhou. O servidor Ollama pode não estar rodando.")
        print("   Por favor, inicie o servidor Ollama manualmente antes de executar este script.")
        return False
    except subprocess.TimeoutExpired:
        print("❌ O comando 'ollama list' expirou. O servidor Ollama pode estar lento ou inacessível.")
        return False

def pull_ollama_model(model_name="phi4-mini:latest"):
    """Baixa o modelo de linguagem especificado usando o cliente Ollama."""
    if not check_ollama_status():
        print("\nNão é possível continuar. O servidor Ollama não está pronto.")
        return

    print(f"\n--- Baixando o modelo {model_name} ---")
    try:
        # CORREÇÃO: Adicionando encoding='utf-8' e errors='ignore' para resolver o UnicodeDecodeError
        result = subprocess.run(
            ['ollama', 'pull', model_name], 
            check=True, 
            text=True, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE,
            encoding='utf-8', # Adicionado para corrigir o UnicodeDecodeError
            errors='ignore' # Adicionado para ignorar caracteres inválidos, se houver
        )
        
        # Imprime a saída do comando Ollama
        print(result.stdout)
        
        print(f"\n✅ Modelo {model_name} baixado com sucesso!")
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Erro ao baixar o modelo {model_name}:")
        print(f"   Código de retorno: {e.returncode}")
        print(f"   Saída de erro (stdout): {e.stdout}")
        print(f"   Saída de erro (stderr): {e.stderr}")
        print("   Verifique se o nome do modelo está correto e se o servidor Ollama está funcionando.")
    except Exception as e:
        print(f"\n❌ Ocorreu um erro inesperado: {e}")

if __name__ == "__main__":
    # O script foca na parte que pode ser automatizada em Python: puxar o modelo.
    
    # O modelo "phi4-mini" é um nome fictício. O usuário deve verificar o nome correto.
    # O usuário deve substituir "phi4-mini" pelo modelo desejado.
    
    pull_ollama_model("phi4-mini")
    
    print("\n\n✅ Configuração do modelo Ollama concluída (se o servidor estava ativo).")