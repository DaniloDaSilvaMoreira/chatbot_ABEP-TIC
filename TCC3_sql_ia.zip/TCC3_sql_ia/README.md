# Projeto TCC - Apenas 2 Microsserviços (SQL e AI)

Este documento fornece as instruções para construir e executar a aplicação do TCC utilizando **Docker** para apenas dois microsserviços: **`sql_service`** e **`ai_service`**.

### Arquitetura Final

*   **Containers (2 Microsserviços):** `sql_service` e `ai_service`.
*   **Serviço Ollama:** Removido do Docker Compose. Deve ser executado **manualmente** no seu *host* (máquina local).
*   **Frontend (Local):** `8_app.py` (Streamlit) rodando diretamente no seu ambiente Python.

## Otimização e Conexão com o Host

*   O `ai_service` foi modificado para se conectar ao Ollama usando o endereço **`http://host.docker.internal:11434`**.
*   O `host.docker.internal` é um nome de host especial que permite que um container Docker acesse o *host* (sua máquina local).

## Pré-requisitos

1.  **Docker** e **Docker Compose** instalados.
2.  **Servidor Ollama** instalado e rodando no seu *host* (máquina local).
3.  **Ambiente Python Local** (para rodar o Streamlit).

## Instruções de Execução

### 1. Iniciar o Servidor Ollama (Manual - Fora do Docker)

Antes de iniciar os containers, você deve garantir que o Ollama esteja rodando na sua máquina local e que o modelo `phi4-mini:latest` esteja baixado.

```bash
# 1. Inicie o servidor Ollama no seu terminal local
ollama serve &

# 2. Baixe o modelo (se ainda não o fez)
ollama pull phi4-mini:latest
```

### 2. Iniciar os 2 Microsserviços Conteinerizados

Certifique-se de estar no diretório que contém o `docker-compose.yml`.

```bash
# 1. Parar e remover containers antigos (se houver)
docker-compose down

# 2. Iniciar os 2 microsserviços (SQL e AI)
docker-compose up --build -d
```

### 2. Verificar o Status do Backend e Debugging

```bash
docker-compose ps
```

VVocê deve ver os dois containers (`tcc_sql_service` e `tcc_ai_service`) com o status `Up`.

**IMPORTANTE (Debugging):** Se o frontend Streamlit retornar um erro `500 Internal Server Error` ao tentar se comunicar com o `ai_service`, o problema é quase sempre que o `ai_service` não conseguiu se conectar ao Ollama. Para ver o erro exato, use o comando de logs:

```bash
docker-compose logs ai_service
```

O log deve indicar se o Ollama não foi encontrado ou se o modelo não foi carregado. Certifique-se de que o Ollama esteja rodando no seu host e que o modelo `phi4-mini:latest` esteja baixado. `Up`.

### 4. Iniciar o Frontend Streamlit Localmente

Você precisará instalar as dependências do Streamlit no seu ambiente Python local.

**Crie um arquivo `requirements.streamlit.txt` no seu diretório local (se ainda não existir):**

```
streamlit
requests
pandas
matplotlib
Pillow
```

**Instale as dependências:**

```bash
pip install -r requirements.streamlit.txt
```

**Execute o Frontend:**

Navegue para o diretório onde está o arquivo `8_app.py` (provavelmente `TCC2/TCC2/`) e execute:

```bash
streamlit run TCC2/TCC2/8_app.py
```

### 5. Acessar a Aplicação

Acesse a interface gráfica em seu navegador: `http://localhost:8501`

### 6. Parar a Aplicação

*   **Frontend:** Pressione `Ctrl+C` no terminal onde o Streamlit está rodando.
*   **Backend:** No diretório do `docker-compose.yml`, execute:
    ```bash
    docker-compose down
    ```
*   **Ollama:** Encontre o processo do Ollama e encerre-o.
