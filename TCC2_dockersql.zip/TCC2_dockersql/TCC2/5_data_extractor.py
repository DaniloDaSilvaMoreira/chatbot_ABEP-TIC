import requests
import pandas as pd
from io import StringIO
import sqlite3
import logging

# ======================================================================
# 1. CONFIGURAÇÕES GLOBAIS
# ======================================================================
NOME_BANCO_DE_DADOS = 'abep_dados.db'
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
}
# Configuração de logging para ambiente local
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# ======================================================================
# 2. FUNÇÕES DE EXTRAÇÃO
# ======================================================================

def extrair_dados_formato_antigo(ano):
    """
    Extrai e processa dados para os anos com layout similar (2020, 2021, 2022, 2023).
    Usa a lógica de detecção 'startswith' que é a mais robusta.
    """
    url_alvo = f'https://abep-tic.org.br/indice-abep-{ano}/'
    logging.info(f"--- Iniciando {ano} com método robusto ---")
    
    try:
        response = requests.get(url_alvo, headers=HEADERS, timeout=20)
        response.raise_for_status()
    except requests.RequestException as e:
        logging.error(f"Erro ao acessar {url_alvo}: {e}")
        return None

    # O uso de 'html5lib' é importante para parsing robusto
    try:
        lista_dfs = pd.read_html(StringIO(response.text), flavor='html5lib')
    except ValueError:
        logging.warning(f"Nenhuma tabela encontrada em {url_alvo}.")
        return None

    dimensoes_encontradas = [None, None, None]

    d1_key = 'D1 – Capacidades'
    d2_key = 'D2 – Oferta'
    d3_key = 'D3 – Regulamentação' if ano in [2020, 2021] else 'D3 – Normatização'

    for df in lista_dfs:
        if df.empty or len(df) < 2: continue
        # Tenta encontrar a dimensão na primeira linha (cabeçalho)
        for item in df.iloc[0]:
            texto_celula = str(item).strip()
            if texto_celula.startswith(d1_key): dimensoes_encontradas[0] = df; break
            elif texto_celula.startswith(d2_key): dimensoes_encontradas[1] = df; break
            elif texto_celula.startswith(d3_key): dimensoes_encontradas[2] = df; break

    tabelas_para_processar = []
    for i, df in enumerate(dimensoes_encontradas):
        if df is not None:
            df_limpo = df.copy()
            # Promove a primeira linha a cabeçalho
            df_limpo.columns = df_limpo.iloc[0]
            df_limpo = df_limpo.drop(0).reset_index(drop=True)
            df_limpo.rename(columns=lambda c: str(c).strip(), inplace=True)
            
            # Renomeia a coluna de pontos (a terceira coluna, índice 2)
            if len(df_limpo.columns) > 2:
                coluna_a_renomear = df_limpo.columns[2]
                df_limpo.rename(columns={coluna_a_renomear: 'PONTOS'}, inplace=True)
            
            if 'Maturidade' in df_limpo.columns:
                df_limpo.drop(columns=['Maturidade'], inplace=True)
            
            df_limpo['DIMENSAO'] = f"D{i+1}"
            tabelas_para_processar.append(df_limpo)

    if not tabelas_para_processar: return None
    df_final = pd.concat(tabelas_para_processar, ignore_index=True)
    
    # Converte a coluna 'PONTOS' para numérica e normaliza
    if 'PONTOS' in df_final.columns:
        df_final['PONTOS'] = pd.to_numeric(df_final['PONTOS'], errors='coerce') / 100
    
    return df_final

def extrair_dados_2025(ano):
    """Extrai e processa dados APENAS para o ano de 2025 (layout diferente)."""
    url_alvo = f'https://abep-tic.org.br/indice-abep-{ano}/'
    logging.info(f"--- Iniciando {ano} com método específico ---")
    
    try:
        response = requests.get(url_alvo, headers=HEADERS, timeout=20)
        response.raise_for_status()
    except requests.RequestException as e:
        logging.error(f"Erro ao acessar {url_alvo}: {e}")
        return None

    try:
        # Tenta ler as tabelas, usando header=0 para a primeira linha ser o cabeçalho
        lista_dfs = pd.read_html(StringIO(response.text), header=0, flavor='html5lib', decimal=',', thousands='.')
    except ValueError:
        logging.warning(f"Nenhuma tabela encontrada em {url_alvo}.")
        return None

    tabelas_para_processar = []
    for df in lista_dfs:
        # Filtra DataFrames que parecem ser as tabelas de interesse
        if {'PONTOS'}.issubset(df.columns) and ('UF' in df.columns or 'CLASSIFICAÇÃO' in df.columns):
            tabelas_para_processar.append(df.copy())

    dados_consolidados = []
    for i, df in enumerate(tabelas_para_processar):
        df_limpo = df.copy()
        
        # Tenta extrair a UF se a coluna 'UF' não existir, mas 'CLASSIFICAÇÃO' sim
        if 'UF' not in df_limpo.columns and 'CLASSIFICAÇÃO' in df_limpo.columns:
            # Extrai a sigla da UF entre parênteses
            df_limpo['UF'] = df_limpo['CLASSIFICAÇÃO'].astype(str).str.extract(r'\((.*?)\)')
        
        # Seleciona e renomeia as colunas de interesse
        if 'UF' in df_limpo.columns and 'PONTOS' in df_limpo.columns:
            df_limpo = df_limpo[['UF', 'PONTOS']].copy()
            df_limpo['DIMENSAO'] = f"D{i+1}"
            dados_consolidados.append(df_limpo)

    if not dados_consolidados: return None
    df_final = pd.concat(dados_consolidados, ignore_index=True)
    
    # Converte 'PONTOS' para numérica
    df_final['PONTOS'] = pd.to_numeric(df_final['PONTOS'], errors='coerce')
    
    # Normaliza as dimensões D4 e D5 (se existirem)
    mask_d4_d5 = df_final['DIMENSAO'].isin(['D4', 'D5'])
    df_final.loc[mask_d4_d5, 'PONTOS'] = df_final.loc[mask_d4_d5, 'PONTOS'] / 100
    
    return df_final

# ======================================================================
# 3. FUNÇÕES AUXILIARES DE BANCO DE DADOS
# ======================================================================
def salvar_no_banco(df, nome_tabela, nome_db):
    """Salva um DataFrame em uma tabela de um banco de dados SQLite."""
    if df is None or df.empty:
        logging.warning(f"Nenhum dado para salvar na tabela '{nome_tabela}'.")
        return

    try:
        # Limpeza e padronização dos dados antes de salvar
        df_final = df.dropna(subset=['PONTOS']).copy()
        
        # Garante que a coluna 'UF' exista e não seja nula
        if 'UF' not in df_final.columns:
            logging.error(f"Coluna 'UF' não encontrada no DataFrame para a tabela '{nome_tabela}'.")
            return
            
        # Padroniza a coluna UF
        df_final.loc[:, 'UF'] = df_final['UF'].astype(str).str.strip().str.upper()
        
        # Seleciona as colunas finais
        df_final = df_final[['UF', 'PONTOS', 'DIMENSAO']]

        conn = sqlite3.connect(nome_db)
        # Salva no banco de dados, substituindo a tabela se ela já existir
        df_final.to_sql(nome_tabela, conn, if_exists='replace', index=False)
        conn.close()
        logging.info(f"✅ Dados salvos com sucesso na tabela '{nome_tabela}'!")
    except Exception as e:
        logging.error(f"ERRO ao salvar dados na tabela '{nome_tabela}': {e}")


def verificar_banco_de_dados(nome_db, tabelas_a_verificar):
    """Verifica se as tabelas foram criadas e exibe as primeiras linhas."""
    logging.info(f"--- Iniciando verificação do banco de dados: '{nome_db}' ---")
    conn = None
    try:
        conn = sqlite3.connect(nome_db)
        for tabela in tabelas_a_verificar:
            try:
                print(f"\n--- Primeiras 5 linhas da tabela: '{tabela}' ---")
                df = pd.read_sql_query(f"SELECT * FROM {tabela} LIMIT 5", conn)
                print(df.to_markdown(index=False))
            except pd.io.sql.DatabaseError:
                print(f"Tabela '{tabela}' não encontrada no banco de dados.")
    finally:
        if conn: conn.close()

# ======================================================================
# 4. BLOCO DE EXECUÇÃO PRINCIPAL
# ======================================================================
if __name__ == "__main__":
    EXTRACTORS = {
        2020: extrair_dados_formato_antigo,
        2021: extrair_dados_formato_antigo,
        2022: extrair_dados_formato_antigo,
        2023: extrair_dados_formato_antigo,
        2025: extrair_dados_2025
    }

    # Adicionando 2024 para garantir que o loop tente todos os anos
    anos_para_coletar = [2020, 2021, 2022, 2023, 2024, 2025]
    
    # Mapeando 2024 para o formato antigo, se o usuário não forneceu um extrator específico
    if 2024 not in EXTRACTORS:
        EXTRACTORS[2024] = extrair_dados_formato_antigo

    print("\n" + "="*60)
    print("      INICIANDO ETAPA DE SCRAPING E SALVAMENTO DE DADOS")
    print("="*60)

    for ano in anos_para_coletar:
        try:
            funcao_extratora = EXTRACTORS.get(ano)
            if funcao_extratora:
                df_ano = funcao_extratora(ano)
                salvar_no_banco(df_ano, f'indices_{ano}', NOME_BANCO_DE_DADOS)
            else:
                logging.warning(f"Nenhuma função extratora definida para o ano {ano}.")
        except Exception as e:
            logging.error(f"FALHA GERAL NO PROCESSAMENTO DO ANO {ano}: {e}")

    print("\n" + "="*60)
    print("      INICIANDO ETAPA DE VERIFICAÇÃO DO BANCO DE DADOS")
    print("="*60)
    tabelas_criadas = [f'indices_{ano}' for ano in anos_para_coletar]
    verificar_banco_de_dados(NOME_BANCO_DE_DADOS, tabelas_criadas)

    print("\n" + "="*60)
    print("      PROCESSO COMPLETO CONCLUÍDO")
    print("="*60)