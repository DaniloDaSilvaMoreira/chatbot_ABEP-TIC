from flask import Flask, request, jsonify
import sqlite3, pandas as pd

app = Flask(__name__)

@app.route('/query', methods=['GET'])
def query_data():
    uf = request.args.get('uf')
    ano = request.args.get('ano')

    if not uf or not ano:
        return jsonify({"error": "Parâmetros 'uf' e 'ano' são obrigatórios"}), 400

    try:
        conn = sqlite3.connect('abep_dados.db')
        # A consulta usa a tabela indices_{ano} e filtra pela UF
        df = pd.read_sql_query(f"SELECT DIMENSAO, PONTOS FROM indices_{ano} WHERE UF = '{uf}'", conn)
        conn.close()

        if df.empty:
            return jsonify({"error": f"Dados não encontrados para UF={uf} no ano={ano}"}), 404

        # Converte o dataframe para uma lista de dicionários para ser serializado em JSON
        dados_dict = df.to_dict(orient='records')
        return jsonify(dados_dict)

    except Exception as e:
        # Captura erros como tabela não encontrada (se o ano for inválido)
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)