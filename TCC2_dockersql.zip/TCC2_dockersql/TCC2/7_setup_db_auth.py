import sqlite3
import os

DB_PATH = 'abep_dados.db'

def setup_auth_tables():
    """Cria as tabelas 'users' e 'conversations' no banco de dados."""
    conn = None
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # Tabela de Usuários
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                name TEXT NOT NULL
            );
        """)

        # Tabela de Conversas
        # O campo 'history' armazenará o histórico de mensagens em formato JSON (TEXT)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                history TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            );
        """)

        conn.commit()
        print(f"Tabelas 'users' e 'conversations' criadas ou já existentes em {DB_PATH}.")

    except sqlite3.Error as e:
        print(f"Erro ao configurar o banco de dados: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == '__main__':
    setup_auth_tables()
