import streamlit as st
import requests, pandas as pd, re
import json
import sqlite3
import bcrypt
from PIL import Image
import io

# --- CONFIGURAÇÕES GLOBAIS ---
st.set_page_config(page_title="Agente ABEP-TIC", page_icon="🤖", layout="wide")
# Se estiver rodando dentro do Docker Compose, use o nome do serviço 'sql_service'
# Se estiver rodando fora do Docker, use 'http://127.0.0.1:5001'
SQL_URL = "http://127.0.0.1:5001" # Valor padrão para rodar fora do Docker
# O usuário precisará ajustar esta variável de ambiente ou a linha de código se for rodar dentro do Docker.
# Por enquanto, manteremos 127.0.0.1, pois a aplicação principal não será containerizada nesta etapa.
# No entanto, vamos adicionar uma variável de ambiente para facilitar a mudança.
# SQL_URL = os.environ.get("SQL_SERVICE_URL", "http://127.0.0.1:5001")
# Para simplificar e manter o foco na containerização do sql_service, vamos manter o 127.0.0.1, pois o serviço será exposto na porta 5001 do host.
# Se a aplicação principal for rodada no host, ela acessará o container via 127.0.0.1:5001.
SQL_URL = "http://127.0.0.1:5001"
AI_URL = "http://127.0.0.1:5002"
DB_PATH = 'abep_dados.db'

MAPA_UF = { 
    'AC': 'Acre', 'AL': 'Alagoas', 'AP': 'Amapá', 'AM': 'Amazonas', 'BA': 'Bahia', 'CE': 'Ceará', 'DF': 'Distrito Federal', 'ES': 'Espírito Santo', 'GO': 'Goiás', 'MA': 'Maranhão', 'MT': 'Mato Grosso', 'MS': 'Mato Grosso do Sul', 'MG': 'Minas Gerais', 'PA': 'Pará', 'PB': 'Paraíba', 'PR': 'Paraná', 'PE': 'Pernambuco', 'PI': 'Piauí', 'RJ': 'Rio de Janeiro', 'RN': 'Rio Grande do Norte', 'RS': 'Rio Grande do Sul', 'RO': 'Rondônia', 'RR': 'Roraima', 'SC': 'Santa Catarina', 'SP': 'São Paulo', 'SE': 'Sergipe', 'TO': 'Tocantins' 
}

# --- Funções de Banco de Dados ---

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row # Permite acessar colunas por nome
    return conn

# --- Funções de Autenticação (Internas) ---

def register_user(email, password, name):
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Verificar se o email já existe
    cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
    if cursor.fetchone():
        conn.close()
        return None, "Este email já está cadastrado."

    # 2. Criptografar a senha
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    # 3. Inserir novo usuário
    try:
        cursor.execute("INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)", 
                       (email, hashed_password, name))
        conn.commit()
        user_id = cursor.lastrowid
        conn.close()
        return {"message": "Usuário registrado com sucesso!", "user_id": user_id}, None
    except sqlite3.Error as e:
        conn.close()
        return None, f"Erro ao registrar usuário: {e}"

def login_user(email, password):
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Buscar usuário pelo email
    cursor.execute("SELECT id, password_hash, name, email FROM users WHERE email = ?", (email,))
    user = cursor.fetchone()
    conn.close()

    if user:
        # 2. Verificar a senha
        if bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
            # Login bem-sucedido
            return {
                "id": user['id'],
                "name": user['name'],
                "email": user['email']
            }, None
        
    # Credenciais inválidas
    return None, "Email ou senha inválidos."

def update_profile(user_id, name=None, password=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    updates = []
    params = []
    
    # 1. Atualizar nome
    if name:
        updates.append("name = ?")
        params.append(name)
        
    # 2. Atualizar senha (criptografada)
    if password:
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        updates.append("password_hash = ?")
        params.append(hashed_password)
        
    if not updates:
        conn.close()
        return None, "Nenhum campo válido para atualização fornecido."

    # 3. Executar a atualização
    try:
        query = f"UPDATE users SET {', '.join(updates)} WHERE id = ?"
        params.append(user_id)
        
        cursor.execute(query, tuple(params))
        conn.commit()
        
        if cursor.rowcount == 0:
            conn.close()
            return None, "Usuário não encontrado."
            
        # 4. Retornar dados atualizados (apenas nome e email)
        cursor.execute("SELECT id, name, email FROM users WHERE id = ?", (user_id,))
        updated_user = cursor.fetchone()
        conn.close()
        
        return {
            "id": updated_user['id'],
            "name": updated_user['name'],
            "email": updated_user['email']
        }, None
        
    except sqlite3.Error as e:
        conn.close()
        return None, f"Erro ao atualizar perfil: {e}"

# --- Funções de Histórico (Internas) ---

def list_conversations(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Seleciona o ID, título e timestamp das conversas do usuário
        cursor.execute("SELECT id, title, timestamp FROM conversations WHERE user_id = ? ORDER BY timestamp DESC", (user_id,))
        conversations = cursor.fetchall()
        conn.close()
        
        # Converte os objetos Row para dicionários
        conversations_list = [dict(conv) for conv in conversations]
        return conversations_list, None
    except sqlite3.Error as e:
        conn.close()
        return None, f"Erro ao listar conversas: {e}"

def get_conversation(conversation_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Seleciona o histórico completo de uma conversa
        cursor.execute("SELECT history FROM conversations WHERE id = ?", (conversation_id,))
        conversation = cursor.fetchone()
        conn.close()
        
        if conversation:
            # O histórico é armazenado como TEXT (JSON string), então precisamos carregar o JSON
            history_json = conversation['history']
            return json.loads(history_json), None
        else:
            return None, "Conversa não encontrada."
    except sqlite3.Error as e:
        conn.close()
        return None, f"Erro ao buscar conversa: {e}"
    except json.JSONDecodeError:
        conn.close()
        return None, "Erro ao decodificar o histórico da conversa."

def save_conversation(user_id, title, history):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Armazena o histórico como uma string JSON
        history_json = json.dumps(history)
        
        cursor.execute("INSERT INTO conversations (user_id, title, history) VALUES (?, ?, ?)", 
                       (user_id, title, history_json))
        conn.commit()
        conversation_id = cursor.lastrowid
        conn.close()
        return {"message": "Conversa salva com sucesso!", "conversation_id": conversation_id}, None
    except sqlite3.Error as e:
        conn.close()
        return None, f"Erro ao salvar conversa: {e}"

def delete_conversation(conversation_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM conversations WHERE id = ?", (conversation_id,))
        conn.commit()
        
        if cursor.rowcount == 0:
            conn.close()
            return None, "Conversa não encontrada."
            
        conn.close()
        return {"message": "Conversa deletada com sucesso!"}, None
    except sqlite3.Error as e:
        conn.close()
        return None, f"Erro ao deletar conversa: {e}"

# --- Funções de Estado e Navegação ---
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "user_info" not in st.session_state:
    st.session_state.user_info = None
if "page" not in st.session_state:
    st.session_state.page = "login" # login, register, chat, profile

def navigate_to(page):
    st.session_state.page = page
    st.rerun()

def logout():
    st.session_state.logged_in = False
    st.session_state.user_info = None
    st.session_state.page = "login"
    st.session_state.messages = [{"role": "assistant", "content": "Você foi desconectado. Por favor, faça login novamente."}]
    st.rerun()

# --- Páginas da Aplicação ---

def login_page():
    # Centraliza o conteúdo
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.title("🤖 Agente ABEP-TIC")
        with st.form("login_form"):
            email = st.text_input("Email")
            password = st.text_input("Senha", type="password")
            submitted = st.form_submit_button("Entrar")
            
            if submitted:
                with st.spinner("Autenticando..."):
                    user_data, error = login_user(email, password)
                    
                    if error:
                        st.error(error)
                    elif user_data:
                        st.session_state.logged_in = True
                        st.session_state.user_info = user_data
                        st.session_state.page = "chat"
                        st.session_state.messages = [{"role": "assistant", "content": f"Bem-vindo(a), {user_data['name']}! Como posso ajudar?"}]
                        st.rerun()
                    else:
                        st.error("Email ou senha inválidos.")
                        
        st.markdown("---")
        st.markdown("Não tem conta? Cadastre-se (clique no botão abaixo)")
        if st.button("Ir para Cadastro"):
            navigate_to("register")

def register_page():
    # Centraliza o conteúdo
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.title("Cadastro de Usuário")
        with st.form("register_form"):
            name = st.text_input("Nome")
            email = st.text_input("Email")
            password = st.text_input("Senha", type="password")
            submitted = st.form_submit_button("Cadastrar")
            
            if submitted:
                with st.spinner("Registrando..."):
                    response, error = register_user(email, password, name)
                    
                    if error:
                        st.error(error)
                    elif response and 'user_id' in response:
                        st.success("Cadastro realizado com sucesso! Faça login para continuar.")
                        navigate_to("login")
                    else:
                        st.error("Erro ao cadastrar. Tente novamente.")
                        
        st.markdown("---")
        st.markdown("Já tem conta? Faça Login (clique no botão abaixo)")
        if st.button("Ir para Login"):
            navigate_to("login")

def profile_page():
    st.title("Meu Perfil")
    user = st.session_state.user_info
    
    st.markdown(f"**Email:** `{user['email']}` (Não pode ser alterado)")
    
    with st.form("profile_form"):
        new_name = st.text_input("Novo Nome", value=user['name'])
        new_password = st.text_input("Nova Senha (deixe em branco para não alterar)", type="password")
        submitted = st.form_submit_button("Atualizar Perfil")
        
        if submitted:
            with st.spinner("Atualizando..."):
                updated_user_data, error = update_profile(user['id'], new_name, new_password if new_password else None)
                
                if error:
                    st.error(error)
                elif updated_user_data:
                    st.session_state.user_info = updated_user_data
                    st.success("Perfil atualizado com sucesso!")
                    st.rerun()
                else:
                    st.error("Erro ao atualizar perfil. Tente novamente.")
                    
    st.markdown("---")
    if st.button("Voltar para o Chat"):
        navigate_to("chat")

# --- Funções de Detecção de Intenção (Mantidas do 8_app.py) ---
def extrair_uf(q):
    """Extrai a sigla da UF da query."""
    q_lower = q.lower()
    
    # 1. Busca por nome completo do estado
    nomes_ordenados = sorted(MAPA_UF.values(), key=len, reverse=True)
    for nome_estado in nomes_ordenados:
        if nome_estado.lower() in q_lower:
            for sigla, nome in MAPA_UF.items():
                if nome == nome_estado: return sigla
                
    # 2. Busca por sigla (regex)
    match = re.search(r'\b(AC|AL|AP|AM|BA|CE|DF|ES|GO|MA|MT|MS|MG|PA|PB|PR|PE|PI|RJ|RN|RS|RO|RR|SC|SP|SE|TO)\b', q, re.IGNORECASE)
    return match.group(0).upper() if match else None # CORREÇÃO AQUI

def extrair_ano(q): 
    """Extrai o ano da query, ou retorna 2025 como padrão."""
    match = re.search(r'\b(2020|2021|2022|2023|2025)\b', q)
    return match.group(0) if match else '2025'

def is_analise(q): 
    """Verifica se a query pede uma análise de dados."""
    return bool(re.search(r'\b(analise|análise|analisar|insights)\b', q, re.IGNORECASE))

# --- Página Principal do Chat ---

def chat_page():
    st.title(f"🤖 Agente ABEP-TIC. Olá, {st.session_state.user_info['name']}!")
    
    # Inicializa o histórico de mensagens se não existir
    if "messages" not in st.session_state:
        st.session_state.messages = [{"role": "assistant", "content": f"Bem-vindo(a), {st.session_state.user_info['name']}! Como posso ajudar?"}]
    
    # --- BARRA LATERAL (HISTÓRICO DE CONVERSAS) ---
    with st.sidebar:
        st.header("Histórico de Conversas")
        
        # Botão para nova conversa
        if st.button("➕ Nova Conversa", use_container_width=True):
            # Salva a conversa atual antes de iniciar uma nova
            if len(st.session_state.messages) > 1:
                # Usa a primeira mensagem do usuário como título
                title = next((msg['content'] for msg in st.session_state.messages if msg['role'] == 'user'), "Nova Conversa")
                save_conversation(st.session_state.user_info['id'], title[:50], st.session_state.messages)
            
            st.session_state.messages = [{"role": "assistant", "content": f"Nova conversa iniciada. Olá, {st.session_state.user_info['name']}! Como posso ajudar?"}]
            st.session_state.current_conversation_id = None # Indica nova conversa
            st.rerun()
            
        st.markdown("---")
        
        # Lista de conversas salvas
        conversations, error = list_conversations(st.session_state.user_info['id'])
        if error:
            st.error(f"Erro ao carregar histórico: {error}")
        elif conversations:
            for conv in conversations:
                col1, col2 = st.columns([4, 1])
                # Botão para carregar conversa
                if col1.button(conv['title'], key=f"load_{conv['id']}", use_container_width=True):
                    history, error = get_conversation(conv['id'])
                    if history:
                        st.session_state.messages = history
                        st.session_state.current_conversation_id = conv['id']
                        st.rerun()
                    else:
                        st.error(f"Erro ao carregar: {error}")
                
                # Botão para deletar conversa
                if col2.button("🗑️", key=f"delete_{conv['id']}", use_container_width=True):
                    delete_conversation(conv['id'])
                    st.success(f"Conversa '{conv['title']}' deletada.")
                    st.rerun()
        else:
            st.info("Nenhuma conversa salva.")
            
        st.markdown("---")
        if st.button("Meu Perfil", use_container_width=True):
            navigate_to("profile")
        if st.button("Sair", use_container_width=True):
            logout()

    # Exibe o histórico de mensagens
    for i, msg in enumerate(st.session_state.messages):
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"], unsafe_allow_html=True)

    # --- BOTÕES DE SUGESTÃO (APENAS NO INÍCIO DA CONVERSA) ---
    if len(st.session_state.messages) == 1:
        suggestions = (
            "O que é ABEP-TIC?",
            "Dados de Tocantins 2023",
            "Fale sobre as 5 dimensões",
            "Fale sobre ABEP-TIC"
        )
        st.markdown("---")
        cols = st.columns(len(suggestions))
        clicked_prompt = None
        for idx, suggestion in enumerate(suggestions):
            if cols[idx].button(suggestion, key=f"suggestion_{idx}", use_container_width=True):
                clicked_prompt = suggestion
        
        if clicked_prompt:
            st.session_state.run_prompt = clicked_prompt
            st.rerun()

    prompt_to_run = st.session_state.pop('run_prompt', None)
    prompt_from_input = st.chat_input("Qual a sua pergunta?")
    prompt = prompt_to_run or prompt_from_input

    # --- PROCESSAMENTO DO CHAT ---
    if prompt:
        # Adiciona a mensagem do usuário ao histórico
        if not st.session_state.messages or st.session_state.messages[-1].get("role") == "assistant" or st.session_state.messages[-1].get("content") != prompt:
             st.session_state.messages.append({"role": "user", "content": prompt})
             with st.chat_message("user"):
                 st.markdown(prompt)

        # Processa a resposta
        with st.chat_message("assistant"):
            with st.spinner("Pensando..."):
                uf, ano, analise = extrair_uf(prompt), extrair_ano(prompt), is_analise(prompt)
                response_html = ""
                message_placeholder = st.empty()
                TIMEOUT_IA = 180 # Timeout para requisições de IA

                try:
                    if analise and uf:
                        # Rota 1: Análise de Dados (AI_URL/analyze)
                        res = requests.get(f"{AI_URL}/analyze", params={"uf": uf, "ano": ano}, timeout=TIMEOUT_IA)
                        res.raise_for_status()
                        
                        if res.status_code == 200 and 'analysis' in res.json():
                            # Correção de sintaxe extrema (usando string de múltiplas linhas)
                            analysis_text = res.json()['analysis']
                            analysis_text = analysis_text.replace('\n', """<br>""")
                            response_html = f"""<div style="font-size: 1rem; text-align: left;">{analysis_text}</div>"""
                        else:
                            response_html = f"""<b><font color='orange'>RESPOSTA INCOMPLETA:</font></b> Serviço /analyze retornou {res.status_code}. Resposta: {res.text[:500]}"""
                            
                    elif uf:
                        # Rota 2: Consulta SQL (SQL_URL/query)
                        res = requests.get(f"{SQL_URL}/query", params={"uf": uf, "ano": ano}, timeout=10)
                        res.raise_for_status()
                        
                        if res.status_code == 200:
                            dados = res.json()
                            if isinstance(dados, list) and dados:
                                df = pd.DataFrame(dados)
                                if 'PONTOS' in df.columns:
                                    # Estiliza o DataFrame para exibição
                                    df_styled = df.style.format({'PONTOS': '{:,.2f}'}).set_table_attributes('class="dataframe"').hide(axis="index").set_caption(f"""<b>Índice {ano} para {MAPA_UF[uf]}</b>""")
                                    response_html = df_styled.to_html().replace('.', ',')
                                else: response_html = f"""Dados para {uf}/{ano} sem coluna 'PONTOS'."""
                            elif isinstance(dados, dict) and 'error' in dados:
                                 response_html = f"""<b><font color='red'>ERRO NO SERVIÇO SQL:</font></b> {dados['error']}"""
                            else: response_html = f"""Não encontrei dados para {uf} em {ano}."""
                        else:
                            response_html = f"""<b><font color='orange'>RESPOSTA INCOMPLETA:</font></b> Serviço /query retornou {res.status_code}. Resposta: {res.text[:500]}"""
                            
                    else: 
                        # Rota 3: Pergunta RAG padrão (AI_URL/ask)
                        res = requests.post(f"{AI_URL}/ask", json={"query": prompt}, timeout=TIMEOUT_IA)
                        res.raise_for_status()
                        
                        if res.status_code == 200 and res.headers.get('content-type') == 'application/json' and 'result' in res.json():
                            data = res.json()
                            response_html = data['result'].replace('\n', """<br>""")
                            if data.get('sources'): 
                                # Correção de sintaxe extrema para a linha 470
                                source_html = """<br><br><i>Fontes:</i><br>"""
                                source_html += "".join([f"""<a href="{f}" target="_blank">{f}</a></a><br>""" for f in data.get('sources',[])])
                                response_html += source_html
                        else:
                            response_html = f"""<b><font color='orange'>RESPOSTA INCOMPLETA:</font></b> Serviço /ask retornou {res.status_code}. Resposta: {res.text[:500]}"""

                except requests.exceptions.Timeout:
                     response_html = f"""<b><font color='orange'>TEMPO ESGOTADO:</font></b> O especialista demorou muito ({TIMEOUT_IA}s). Verifique se o servidor Ollama está ativo."""
                except requests.exceptions.RequestException as e:
                    try: error_details = e.response.json() if e.response else str(e)
                    except: error_details = str(e)
                    response_html = f"""<b><font color='red'>ERRO DE COMUNICAÇÃO:</font></b> Não foi possível contatar microsserviço.<br>Detalhes: {error_details}"""
                except Exception as e:
                     response_html = f"""<b><font color='red'>ERRO INESPERADO:</font></b> {e}"""

                if not response_html: response_html = """Desculpe, não consegui processar."""
                
                message_placeholder.markdown(response_html, unsafe_allow_html=True)
                
                # Adiciona a resposta do assistente ao histórico
                if not st.session_state.messages or st.session_state.messages[-1].get("role") != "assistant" or st.session_state.messages[-1].get("content") != response_html:
                     st.session_state.messages.append({"role": "assistant", "content": response_html})
                     
                # Salva a conversa após a resposta do assistente (se for uma nova conversa)
                if 'current_conversation_id' not in st.session_state or st.session_state.current_conversation_id is None:
                    # Usa a primeira mensagem do usuário como título
                    title = next((msg['content'] for msg in st.session_state.messages if msg['role'] == 'user'), "Nova Conversa")
                    save_conversation(st.session_state.user_info['id'], title[:50], st.session_state.messages)
                    # Não exibe erro para o usuário, apenas loga.

# --- LÓGICA PRINCIPAL DE ROTEAMENTO ---

if st.session_state.logged_in:
    if st.session_state.page == "chat":
        chat_page()
    elif st.session_state.page == "profile":
        profile_page()
    else: # Caso esteja logado mas em uma página inválida, volta para o chat
        navigate_to("chat")
else:
    if st.session_state.page == "register":
        register_page()
    else: # Padrão é a página de login
        login_page()