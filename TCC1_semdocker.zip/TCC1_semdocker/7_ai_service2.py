from flask import Flask, request, jsonify
import sqlite3, pandas as pd, re
import os
from datetime import datetime
from langchain_ollama.llms import OllamaLLM
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate

app = Flask(__name__)

# --- CONFIGURAÇÕES E CARREGAMENTO ÚNICO ---
llm = None
qa_chain = None

NOMES_DIMENSOES = {
    'D1': "Dimensão I - Capacidades para a oferta digital de serviços",
    'D2': "Dimensão II - Oferta de Serviços PúblicOS Digitais",
    'D3': "Dimensão III – Normatização sobre Modernização para a Oferta de Serviços PúblicOS Digitais",
    'D4': "Dimensão IV – Inclusividade na Oferta de Serviços Públicos",
    'D5': "Dimensão V – Inovação na Oferta de Serviços Públicos"
}

RECOMENDACOES = {
    'D1': "Investir em um Portal Único de Serviços e aplicativo unificado.",
    'D2': "Mapear e digitalizar os serviços mais procurados presencialmente.",
    'D3': "Criar ou atualizar a Lei de Governo Digital estadual e instituir um Comitê de Governança.",
    'D4': "Instituir uma política oficial de Linguagem Simples e treinar os servidores.",
    'D5': "Criar laboratórios de inovação (iLabs) e utilizar análise de dados para tomada de decisões."
}

MAPA_UF = { 
    'AC': 'Acre', 'AL': 'Alagoas', 'AP': 'Amapá', 'AM': 'Amazonas', 'BA': 'Bahia', 'CE': 'Ceará', 'DF': 'Distrito Federal', 'ES': 'Espírito Santo', 'GO': 'Goiás', 'MA': 'Maranhão', 'MT': 'Mato Grosso', 'MS': 'Mato Grosso do Sul', 'MG': 'Minas Gerais', 'PA': 'Pará', 'PB': 'Paraíba', 'PR': 'Paraná', 'PE': 'Pernambuco', 'PI': 'Piauí', 'RJ': 'Rio de Janeiro', 'RN': 'Rio Grande do Norte', 'RS': 'Rio Grande do Sul', 'RO': 'Rondônia', 'RR': 'Roraima', 'SC': 'Santa Catarina', 'SP': 'São Paulo', 'SE': 'Sergipe', 'TO': 'Tocantins' 
}

def load_models():
    """Carrega os modelos de IA e a cadeia RAG."""
    global llm, qa_chain
    print("Carregando modelos do serviço de IA (RAG + Análise)...")
    try:
        # Inicializa o LLM (Ollama deve estar rodando)
        MODEL_NAME = os.environ.get("OLLAMA_MODEL", "phi4-mini:latest")
        llm = OllamaLLM(model=MODEL_NAME, temperature=0.1)
        
        # Carrega o índice FAISS
        embedding_model = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        vector_store_loaded = FAISS.load_local("faiss_index_abep_tic", embedding_model, allow_dangerous_deserialization=True)
        retriever = vector_store_loaded.as_retriever(search_kwargs={"k": 5})
        
        # Configura o Prompt RAG
        prompt_template_rag = '''Você é um assistente factual da ABEP-TIC. Use o contexto para responder. Se não souber, diga que não encontrou. Contexto:{context} Pergunta:{question} Resposta:'''
        PROMPT_RAG = PromptTemplate(template=prompt_template_rag, input_variables=["context", "question"])
        
        # Cria a cadeia RAG
        qa_chain = RetrievalQA.from_chain_type(
            llm=llm, 
            chain_type="stuff", 
            retriever=retriever, 
            return_source_documents=True, 
            chain_type_kwargs={"prompt": PROMPT_RAG}
        )
        print("✅ Serviço de IA pronto.")
    except Exception as e:
        print(f"Erro crítico ao carregar modelos de IA: {e}")
        llm = None
        qa_chain = None

# Carrega os modelos ao iniciar o serviço
load_models()

def run_query(query):
    """Executa uma consulta SQL no banco de dados."""
    conn = sqlite3.connect('abep_dados.db')
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

@app.route('/ask', methods=['POST'])
def ask_rag():
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}] Request received for: /ask")
    """Endpoint para perguntas RAG."""
    if not llm or not qa_chain: 
        return jsonify({"error": "Modelo de IA não carregado. Verifique o servidor Ollama."}), 500

    query = request.json.get('query')
    if not query: 
        return jsonify({"error": "Query obrigatória"}), 400

    try:
        # Lógica de atalho para as 5 dimensões
        if "5 dimensões" in query.lower() or "cinco dimensões" in query.lower():
             dimensoes_texto = "\n".join([f"- {k}: {v}" for k, v in NOMES_DIMENSOES.items()])
             resposta = f"As 5 dimensões avaliadas no índice ABEP-TIC são:\n{dimensoes_texto}"
             return jsonify({"result": resposta, "sources": []})

        # Executa a cadeia RAG
        res = qa_chain.invoke({"query": query})
        
        # Extrai as fontes
        fontes = {doc.metadata.get('source', 'N/A') for doc in res.get('source_documents', [])}
        fontes_lista = list(fontes)

        return jsonify({
            "result": res.get('result', 'Não foi possível gerar uma resposta.'), 
            "sources": fontes_lista
        })

    except Exception as e: 
        return jsonify({"error": str(e)}), 500

@app.route('/analyze', methods=['GET'])
def analyze_data():
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}] Request received for: /analyze")
    """Endpoint para análise de dados e geração de relatório pelo LLM."""
    if not llm: 
        return jsonify({"error": "Modelo de IA não carregado. Verifique o servidor Ollama."}), 500

    uf = request.args.get('uf')
    ano = request.args.get('ano')

    if not uf or not ano: 
        return jsonify({"error": "UF e Ano obrigatórios"}), 400

    try:
        # 1. Busca os dados da UF e do Líder
        dados_df = run_query(f"SELECT DIMENSAO, PONTOS FROM indices_{ano} WHERE UF = '{uf}'")
        if dados_df.empty: 
            return jsonify({"error": f"Dados não encontrados para {uf}/{ano}"}), 404

        lideres_df = run_query(f"SELECT DIMENSAO, UF, MAX(PONTOS) as PONTOS FROM indices_{ano} GROUP BY DIMENSAO")
        lideres_map = lideres_df.groupby('DIMENSAO')['UF'].apply(lambda x: ', '.join(x)).to_dict()
        pontos_max_map = lideres_df.set_index('DIMENSAO')['PONTOS'].to_dict()

        # 2. Prepara o texto para o prompt
        dados_texto = "\n".join([
            f"- {row['DIMENSAO']}: {row['PONTOS']:.2f} de {pontos_max_map.get(row['DIMENSAO'], 0):.2f} pts. (Líder: {lideres_map.get(row['DIMENSAO'], 'N/A')})" 
            for _, row in dados_df.iterrows()
        ])

        # 3. Calcula o maior GAP para sugestão estratégica
        dados_df['gap'] = dados_df['DIMENSAO'].apply(lambda d: pontos_max_map.get(d, 0)) - dados_df['PONTOS']
        
        # Calcula o percentual (opcional, mas bom para o raciocínio do LLM)
        dados_df['percentual'] = dados_df.apply(
            lambda row: (row['PONTOS'] / pontos_max_map.get(row['DIMENSAO'], 1)) * 100 
            if pontos_max_map.get(row['DIMENSAO'], 0) > 0 else 0, 
            axis=1
        )

        dim_maior_gap = 'N/A'
        gaps_positivos = dados_df[dados_df['gap'] >= 0]
        if not gaps_positivos.empty:
            dim_maior_gap = gaps_positivos.loc[gaps_positivos['gap'].idxmax()]['DIMENSAO']

        sugestao_foco = {
            "dimensao": dim_maior_gap, 
            "lideres": lideres_map.get(dim_maior_gap, 'N/A'), 
            "recomendacao": RECOMENDACOES.get(dim_maior_gap, "N/A")
        }

        # 4. Cria o Prompt de Análise
        prompt_analise = f'''Sua tarefa é agir como um analista de dados sênior e criar um relatório sobre {MAPA_UF[uf]} em {ano}.

**Dados:**\n{dados_texto}

**Nomes Oficiais:** D1:{NOMES_DIMENSOES['D1']}, D2:{NOMES_DIMENSOES['D2']}, D3:{NOMES_DIMENSOES['D3']}, D4:{NOMES_DIMENSOES['D4']}, D5:{NOMES_DIMENSOES['D5']}

**INSTRUÇÕES ESTRITAS:**
1. Raciocínio: Para cada dimensão, calcule a %. Use: >85%=Excelente, 60-84%=Bom, <60%=Atenção.
2. Linguagem: Use português do Brasil.
3. Formato: Texto puro. SEM Markdown.
4. Título: "Análise de Desempenho: {MAPA_UF[uf]} ({ano})".
5. Subseção "Desempenho por Dimensão": Descreva o status (Excelente/Bom/Atenção) para cada dimensão.
6. Subseção "Conclusão Geral": Resumo fiel.
7. Subseção "Sugestão Estratégica": Parágrafo fluido. Se líder, sugira inovação. Senão, foque na {sugestao_foco['dimensao']}. Sugira se inspirar nos líderes ({sugestao_foco['lideres']}) e elabore sobre "{sugestao_foco['recomendacao']}". Quebra de linha antes do título.
'''
        # 5. Invoca o LLM para gerar a análise
        resposta_analitica = llm.invoke(prompt_analise)

        return jsonify({"analysis": resposta_analitica})

    except Exception as e: 
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # O host '0.0.0.0' é necessário para que o serviço seja acessível externamente (pelo Streamlit)
    app.run(host='0.0.0.0', port=5002)